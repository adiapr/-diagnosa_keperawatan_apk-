<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pengkajian;
use App\Models\User;
use Illuminate\Pagination\Paginator;

class PengkajianController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function pengkajian(){
        // alert()->success('Selamat Datang','Tekan OK untuk melanjutkan');
        return view('admin.pengkajian');
    }

    public function pengkajian_index(){
        alert()->success('Selamat Datang','Tekan OK untuk melanjutkan');
        return view('admin.index');
    }

    public function pengkajian_add(Request $request){

        $pengkajian = new Pengkajian;

        $pengkajian->namapasien         = $request->nama;
        $pengkajian->usia               = $request->usia;
        $pengkajian->tgl_lahir           = $request->tanggal;
        $pengkajian->rr                  = $request->rr;
        $pengkajian->jenis_kelamin       = $request->jk;
        $pengkajian->ruang_rawat         = $request->ruang;
        $pengkajian->tgl_pengkajian      = date('Y-m-d');
        $pengkajian->sistole             = $request->sistole;
        $pengkajian->diastole            = $request->diastole;
        $pengkajian->nadi                = $request->nadi;
        $pengkajian->kesadaran           = $request->kesadaran;
        $pengkajian->pps                 = $request->pps_level;
        $pengkajian->ecog                = $request->ecog;
        $pengkajian->vas                 = $request->vas;
        $pengkajian->lok_nyeri           = $request->lokasi_nyeri;
        $pengkajian-> kualitas_nyeri     = $request->kualitasnyeri;
        $pengkajian->frekuensi_nyeri     = $request->frekuensinyeri;
        $pengkajian->durasi_nyeri        = $request->durasinyeri;
        $pengkajian->periode_waktu       = $request->periodenyeri;
        $pengkajian->wajah               = $request->wajah;
        $pengkajian->aktivitas           = $request->aktivitas;
        $pengkajian->posisi_tubuh        = $request->Posisi;
        $pengkajian->visiologi1          = $request->fisiologi1;
        $pengkajian->visiologi2          = $request->fisiologi2;
        $pengkajian->tambahanlain        = $request->tambahan_nyeri;
        $pengkajian->lokasi_nyeri        = $request->lokasi_nyeri;
        $pengkajian->aktivitas1          = $request->aktivitas1;
        $pengkajian->gejalalain          = $request->gejalalain;
        $pengkajian->polaistirahat       = $request->polaistirahat;
        $pengkajian->keluhan             = $request->keluhan;
        $pengkajian->tb                  = $request->tb;
        $pengkajian->bb                  = $request->bb;
        $pengkajian->imt                 = $request->imt;
        $pengkajian->interpretasi        = $request->interpretasi;
        $pengkajian->membranmukosa       = $request->membranmukosa;
        $pengkajian->edema               = $request->edema;
        $pengkajian->dehidrasi           = $request->dehidrasi;
        $pengkajian->urin                = $request->urin;
        $pengkajian->terapi              = $request->terapi;
        $pengkajian->tandagejala         = $request->tandagejala;
        $pengkajian->batuk               = $request->batuk;
        $pengkajian->sputum              = $request->sputum;
        $pengkajian->obn                 = $request->obn;
        $pengkajian->jantung             = $request->jantung;
        $pengkajian->suaranafas          = $request->suaranafas;
        $pengkajian->akral               = $request->akral;
        $pengkajian->warnakulit          = $request->warnakulit;
        $pengkajian->crt                 = $request->crt;
        $pengkajian->hepatojuglar        = $request->hepatojuglar;
        $pengkajian->po2                 = $request->po2;
        $pengkajian->nilaipo2            = $request->nilaipo2;
        $pengkajian->ph                  = $request->ph;
        $pengkajian->nilaiph             = $request->nilaiph;
        $pengkajian->sato2               = $request->sato2;
        $pengkajian->nilaisato2          = $request->nilaisato2;
        $pengkajian->jvp                 = $request->jvp;
        $pengkajian->cvp                 = $request->cvp;
        $pengkajian->vtidal              = $request->vtidal;
        $pengkajian->hematokrit          = $request->hematokrit;
        $pengkajian->fration             = $request->fration;
        $pengkajian->gejalalain95        = $request->gejalalain95;
        $pengkajian->keluhanberkemih     = $request->keluhanberkemih;
        $pengkajian->volurine            = $request->volurine;
        $pengkajian->bab                 = $request->bab;
        $pengkajian->konsistensi         = $request->konsistensi;
        $pengkajian->kelbab              = $request->kelbab;
        $pengkajian->bablain             = $request->bablain;
        $pengkajian->neurosensor         = $request->neurosensor;
        $pengkajian->reproduksi          = $request->reproduksi;
        $pengkajian->reproduksilain      = $request->reproduksilain;
        $pengkajian->mandi               = $request->mandi;
        $pengkajian->berpakaian          = $request->berpakaian;
        $pengkajian->bababak             = $request->bababak;
        $pengkajian->berhias             = $request->berhias;
        $pengkajian->makanminum          = $request->makanminum;
        $pengkajian->kebersihandiri      = $request->kebersihandiri;
        $pengkajian->riwayat             = $request->riwayat;
        $pengkajian->apapunyapenyakit    = $request->apapunyapenyakit;
        $pengkajian->alatjalan           = $request->alatjalan;
        $pengkajian->gayajalan           = $request->gayajalan;
        $pengkajian->berpindahlain       = $request->berpindahlain;
        $pengkajian->tinggalbersama      = $request->tinggalbersama;
        $pengkajian->adakahtergantung    = $request->adakahtergantung;
        $pengkajian->masalahkeluarga     = $request->masalahkeluarga;
        $pengkajian->dukunganlain        = $request->dukunganlain;
        $pengkajian->butuhdukungan       = $request->butuhdukungan;
        $pengkajian->masalahdukungan     = $request->masalahdukungan;
        $pengkajian->pikiranmengganggu   = $request->pikiranmengganggu;
        $pengkajian->harapanpasien       = $request->harapanpasien;
        $pengkajian->pendapatpasien      = $request->pendapatpasien;
        $pengkajian->kopingpasien        = $request->kopingpasien;
        $pengkajian->kondisiverbal       = $request->kondisiverbal;
        $pengkajian->lainnyapasien       = $request->lainnyapasien;

        $pengkajian->save();
        alert()->success('DATA TERSIMPAN','Tekan OK untuk melanjutkan');
        return view('admin.pengkajian');
    }

    public function pengkajian_hapus($id){
        $pengkajian = Pengkajian::find($id);

        $pengkajian->delete();
        alert()->warning('Data Dihapus','Tekan OK untuk melanjutkan');
        return redirect('/resume');
    }

    public function pengkajian_resume(){
        $batas      = 10;
        $jmldata    = Pengkajian::count();
        $resume     = Pengkajian::orderBy('id','desc')
                        ->paginate($batas);
        $no         = 0;
        // alert()->success('Data Resume','Tekan OK untuk melanjutkan');
        return view('admin.resume', compact('jmldata', 'resume', 'no'));
    }

    public function index_akun(){
        return view('admin.akun');
    }

    public function update_akun(Request $request, $id){
        $user = User::find($id);

        $user->name = $request->nama;
        $user->update();
        alert()->success('Data Diperbaharui','Tekan OK untuk melanjutkan');
        return redirect('/akun');
    }
}
