@extends('admin.pages.main2')


@section('content')
@include('sweetalert::alert')
<div class="container-fluid">

    <div class="row">
        <div class="col-lg-12">
            <h3 class="page-header">Pengkajian Paliatif</h3>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="table-responsive">
                <table class="table table-hover">
                    <tr>
                        <th>#</th>
                        <th>Nama Pasien</th>
                        <th>Usia</th>
                        <th>Tanggal Lahir</th>
                        <th>Jenis Kelamin</th>
                        <th>Ruang Rawat</th>
                        <th>Tanggal Pengkajian</th>
                        <th>Aksi</th>
                    </tr>
                    @foreach ($resume as $data)
                        <tr>
                            <td>{{ ++$no }}</td>
                            <td><a href="#"><b>{{ $data->namapasien }}</b></a></td>
                            <td>{{ $data->usia }} th</td>
                            <td>{{ $data->tgl_lahir }}</td>
                            <td>{{ $data->jenis_kelamin }}</td>
                            <td>{{ $data->ruang_rawat }}</td>
                            <td>{{ $data->tgl_pengkajian }}</td>
                            <td>
                                <form action="/hapusData/{{ $data->id }}" method="post">
                                    @csrf
                                    <button class="btn btn-danger btn-sm" onClick="return confirm('Yakin mau dihapus ?')"><i class="fa fa-trash"></i> Hapus</button>
                                    <a href="/exportlaporan/{{ $data->id }}" class="btn btn-success btn-sm"><i class="fa fa-file-pdf-o"></i> Download</a>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </table>
                <a href="https://drive.google.com/file/d/1i6kd0OckdKVNF6DYepffwXJsZQ-QjA-Z/view">Download</a>
            </div>
        </div>
    </div>
</div>
@endsection


