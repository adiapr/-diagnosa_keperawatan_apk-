<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
        integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
</head>

<body>
    <div class="container mt-4">
        <div class="row"  style="border:solid 4px black">
            <div class="col-md-12">
                <h2 align="center">Resume Asuhan keperawatan</h2>
                <hr>
            </div>
            <div class="col-md-12">
                <table width="100%">
                    <tr>
                        <td width="25%">Nama Pasien</td>
                        <td width="2">:</td>
                        <td>{{  $data1->namapasien  }}</td>
                    </tr>
                    <tr>
                        <td>Usia</td>
                        <td> : </td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Tanggal Lahir</td>
                        <td> : </td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Jenis Kelamin</td>
                        <td> : </td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Ruang Rawat</td>
                        <td> : </td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Tanggal Pengkajian</td>
                        <td> : </td>
                        <td></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</body>

</html>
