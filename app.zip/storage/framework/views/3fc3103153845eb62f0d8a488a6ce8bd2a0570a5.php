<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
        integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
</head>

<body>
    <div class="container mt-4">
        <div class="row"  style="border:solid 4px black">
            <div class="col-md-12">

                <h2 align="center"><img src="http://diagnosa.mangroveleather.id/img/logo.webp"  alt="" width="300"><br>
                    Resume Asuhan keperawatan</h2>
                <hr>
            </div>
            <?php $__currentLoopData = $data1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-12">
                <table width="100%">
                    <tr>
                        <td width="25%">Nama Pasien</td>
                        <td width="2">:</td>
                        <td><?php echo e($data1->namapasien); ?></td>
                    </tr>
                    <tr>
                        <td>Usia</td>
                        <td> : </td>
                        <td><?php echo e($data1->usia); ?></td>
                    </tr>
                    <tr>
                        <td>Tanggal Lahir</td>
                        <td> : </td>
                        <td><?php echo e($data1->tgl_lahir); ?></td>
                    </tr>
                    <tr>
                        <td>Jenis Kelamin</td>
                        <td> : </td>
                        <td><?php echo e($data1->jenis_kelamin); ?></td>
                    </tr>
                    <tr>
                        <td>Ruang Rawat</td>
                        <td> : </td>
                        <td><?php echo e($data1->ruang_rawat); ?></td>
                    </tr>
                    <tr>
                        <td>Tanggal Pengkajian</td>
                        <td> : </td>
                        <td><?php echo e($data1->tgl_pengkajian); ?></td>
                    </tr>
                </table>
                <hr>
                <table>
                    <tr>
                        <td>TD</td>
                        <td> : </td>
                        <td><?php echo e($data1->sistole); ?>/<?php echo e($data1->diastole); ?> mmhg</td>
                    </tr>
                    <tr>
                        <td>RR</td>
                        <td> : </td>
                        <td>
                            <?php if($data1->rr >24): ?>
                            <?php echo e($data1->rr); ?> x/mnt <b>(Takipnea)</b>
                            <?php elseif($data1->rr <16): ?>
                            <?php echo e($data1->rr); ?> x/mnt <b>(Bradipnea)</b>
                            <?php else: ?>
                            <?php echo e($data1->rr); ?> x/mnt <b>(Normal)</b>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Nadi</td>
                        <td> : </td>
                        <td>
                            <?php if($data1->nadi <60): ?>
                            <?php echo e($data1->nadi); ?> x/mnt <b>(Nadi Menurun)</b>
                            <?php elseif($data1->nadi >100): ?>
                            <?php echo e($data1->nadi); ?> x/mnt <b>(Nadi Meningkat)</b>
                            <?php else: ?>
                            <?php echo e($data1->nadi); ?> x/mnt <b>(Normal)</b>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Suhu</td>
                        <td> : </td>
                        <td>
                            <?php if($data1->suhu <36): ?>
                            <?php echo e($data1->suhu); ?> <sup>0</sup>C <b>(Suhu Rendah)</b>
                            <?php elseif($data1->suhu >37): ?>
                            <?php echo e($data1->suhu); ?> <sup>0</sup>C <b>(Suhu Tinggi)</b>
                            <?php else: ?>
                            <?php echo e($data1->suhu); ?> <sup>0</sup>C <b>(Normal)</b>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Kesadaran</td>
                        <td> : </td>
                        <td><?php echo e($data1->kesadaran); ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH /home/adiloveedi/Laravel/appPaker/resources/views/resume/laporan.blade.php ENDPATH**/ ?>