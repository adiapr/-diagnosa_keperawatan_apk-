<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid">

    <div class="row">
        <div class="col-lg-12">
            <h3 class="page-header">Pengkajian Paliatif</h3>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="table-responsive">
                <table class="table table-hover">
                    <tr>
                        <th>#</th>
                        <th>Nama Pasien</th>
                        <th>Usia</th>
                        <th>Tanggal Lahir</th>
                        <th>Jenis Kelamin</th>
                        <th>Ruang Rawat</th>
                        <th>Tanggal Pengkajian</th>
                        <th>Aksi</th>
                    </tr>
                    <?php $__currentLoopData = $resume; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$no); ?></td>
                            <td><a href="#"><b><?php echo e($data->namapasien); ?></b></a></td>
                            <td><?php echo e($data->usia); ?> th</td>
                            <td><?php echo e($data->tgl_lahir); ?></td>
                            <td><?php echo e($data->jenis_kelamin); ?></td>
                            <td><?php echo e($data->ruang_rawat); ?></td>
                            <td><?php echo e($data->tgl_pengkajian); ?></td>
                            <td>
                                <form action="/hapusData/<?php echo e($data->id); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-danger btn-sm" onClick="return confirm('Yakin mau dihapus ?')"><i class="fa fa-trash"></i> Hapus</button>
                                    <a href="/exportlaporan/<?php echo e($data->id); ?>" class="btn btn-success btn-sm"><i class="fa fa-file-pdf-o"></i> Download</a>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <a href="https://drive.google.com/file/d/1i6kd0OckdKVNF6DYepffwXJsZQ-QjA-Z/view">Download</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.pages.main2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adiloveedi/Laravel/appPaker/resources/views/admin/resume.blade.php ENDPATH**/ ?>