<nav class="navbar navbar-inverse navbar-fixed-bottom d-none d-lg-none d-xl-none align-items-center" style="valign:mid">
            
    <table width="100%" border="0" style="margin-top:10px;font-size:20px;color:white">
        <tr width="100%" align="center">
            <td width="33%"  valign="middle"><a href="/pengkajian"><b><i class="fa fa-home"></b></i></a></td>
            <td width="34%"  valign="middle"><a href="inputorder.php"><i class="fa fa-th"></i></a></td>
            <td width="33%"  valign="middle"><a href="inputkurir.php"><i class="fa fa-user"></i></a></td>
        </tr>
    </table>
  </nav><?php /**PATH C:\Laravel\diagnosa\resources\views/admin/pages/footnav.blade.php ENDPATH**/ ?>