<nav class="navbar navbar-inverse navbar-fixed-bottom d-none d-lg-none d-xl-none align-items-center" style="valign:mid">

    <table width="100%" border="0" style="margin-top:10px;font-size:16px;color:white">
        <tr width="100%" align="center">
            <td width="25%"  valign="middle"><a href="/" style="color:white"><b><i class="fa fa-home"><br>Home</b></i></a></td>
            <td width="25%"  valign="middle"><a href="/pengkajian" style="color:white"><b><i class="fa fa-list-alt"><br>Pengkajian</b></i></a></td>
            <td width="25%"  valign="middle"><a href="/resume" style="color:white"><i class="fa fa-th"></i><br>Resume</a></td>
            <td width="25%"  valign="middle"><a href="/akun" style="color:white"><i class="fa fa-user"></i><br>Akun</a></td>
        </tr>
    </table>
  </nav>
<?php /**PATH /home/u7693570/public_html/diagnosa.mangroveleather.id/resources/views/admin/pages/footnav.blade.php ENDPATH**/ ?>