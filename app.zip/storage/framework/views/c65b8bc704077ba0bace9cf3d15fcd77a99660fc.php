<nav class="navbar navbar-inverse navbar-fixed-bottom d-none d-lg-none d-xl-none align-items-center" style="valign:mid">

    <table width="100%" border="0" style="margin-top:10px;font-size:20px;color:white">
        <tr width="100%" align="center">
            <td width="33%"  valign="middle"><a href="/" style="color:white"><b><i class="fa fa-home"><br>Home</b></i></a></td>
            <td width="34%"  valign="middle"><a href="#"><i class="fa fa-th"></i><br>Resume</a></td>
            <td width="33%"  valign="middle"><a href="#"><i class="fa fa-user"></i><br>Akun</a></td>
        </tr>
    </table>
  </nav>
<?php /**PATH /home/adiloveedi/Laravel/diagnosa_keperawatan_apk/resources/views/admin/pages/footnav.blade.php ENDPATH**/ ?>